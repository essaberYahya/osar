<template>
    <label class="block font-medium text-sm text-gray-700">
        <i :class="icon+' linkicon'"></i>
        <span v-if="value">{{ value }}</span>
        <span v-else><slot></slot></span>
    </label>
</template>

<script>
    import { defineComponent } from 'vue'

    export default defineComponent({
        props: ['value','icon']
    })
</script>

<style scoped>
.linkicon {
    font-size: 23px;
    margin-right: 1%;
    padding: 1%;
    color: #2f5a83;
}
</style>

