<template>
<img src="../../img/vanotic.png">
</template>
