<template>
  <section id="services" class="wrapper bg-light wrapper-border">
    <div class="container py-14 py-md-16 text-center">
      <div class="row">
        <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-2">
          <h2 class="fs-15 text-uppercase text-muted mb-3">What We Do?</h2>
          <h3 class="display-4 mb-10 px-xl-10">
            The service we offer is specifically designed to meet your needs.
          </h3>
        </div>
        <!-- /column -->
      </div>
      <!-- /.row -->
      <div class="position-relative">
        <div
          class="shape rounded-circle bg-soft-blue rellax w-16 h-16"
          data-rellax-speed="1"
          style="bottom: -0.5rem; right: -2.2rem; z-index: 0"
        ></div>
        <div
          class="shape bg-dot yellow rellax w-16 h-17"
          data-rellax-speed="1"
          style="top: -0.5rem; left: -2.5rem; z-index: 0"
        ></div>
        <div class="row gx-md-5 gy-5 text-center">
          <div
            class="col-md-6 col-xl-3"
            v-for="service in ourServices"
            :key="service.id"
          >
            <div class="card shadow-lg">
              <div class="card-body">
                <div
                  :class="
                    'icon btn btn-circle btn-lg disabled mb-5 me-5 btn-soft-' +
                    service.color
                  "
                >
                  <i :class="service.icon"></i>
                </div>
                <h4>{{ service.title }}</h4>
                <p class="mb-2">{{ service.description.substring(0, 60) }}</p>
              </div>
              <!--/.card-body -->
            </div>
            <!--/.card -->
          </div>
        </div>
        <!--/.row -->
      </div>
      <!-- /.position-relative -->
    </div>
    <!-- /.container -->
  </section>
</template>
<script>
export default {
  props: ["ourServices"],
};
</script>
<style scoped>
.tts {
  font-family: "Lora", serif;
}
</style>
