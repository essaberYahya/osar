<template>
    <div>
        <ServiceNotAvailableVue></ServiceNotAvailableVue>
    </div>
</template>
<script>
import ServiceNotAvailableVue from './Partials/ServiceNotAvailable.vue'

export default {
    components : {
        ServiceNotAvailableVue
    }
}
</script>
