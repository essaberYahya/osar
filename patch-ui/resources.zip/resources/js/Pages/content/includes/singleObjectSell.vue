<template>
  <div>
    <singleProjectIntroVue
      :vtitle="item.category.name"
      :vdescription="item.title"
      :vcreated_at="item.created_at"
    ></singleProjectIntroVue>

    <section class="wrapper bg-light wrapper-border">
      <div class="container py-14 py-md-16">
        <div class="row align-items-center mb-10">
          <div class="col-md-8 col-lg-9 col-xl-8 col-xxl-7 pe-xl-20">
            <h3 class="display-4 mb-0">Product : {{ item.title }}</h3>
            <p>You can ask for quotation by click on ask quotatio</p>
          </div>
          <!--/column -->
          <div class="col-md-4 col-lg-3 ms-md-auto text-md-end mt-5 mt-md-0">
            <Link
              href="/products"
              class="btn btn-soft-primary rounded-pill mb-0"
              >see all products</Link
            >
          </div>
          <!--/column -->
        </div>
        <!--/.row -->
        <div class="row gx-lg-6 gx-xl-11 gy-10 blog grid-view">
          <div class="col-lg-12">
            <article class="post row">
              <div class="col-12 col-md-6">
                <div class="rounded mb-6">
                  <img :src="asset + item.pictureCover" class alt />
                  <!-- /.basic-slider -->
                </div>
              </div>
              <div class="col-12 col-md-6 mt-5">
                <!-- /.post-slider -->
                <div class="post-header mb-5">
                  <div class="post-category text-line">
                    <a href="#" class="hover" rel="category">{{
                      item.category.name
                    }}</a>
                  </div>
                  <!-- /.post-category -->
                  <h2 class="post-title mt-1 mb-4">{{ item.title }}</h2>
                  <ul class="post-meta mb-0">
                    <li class="post-date">
                      <i class="uil uil-calendar-alt"></i>
                      <span
                        >Commance le :
                        {{ new Date(item.startAt).toDateString() }}</span
                      >
                    </li>
                    <li class="post-author">
                      <a href="#">
                        <i class="uil uil-user"></i>
                        <span
                          >Fin le :
                          {{ new Date(item.startAt).toDateString() }}</span
                        >
                      </a>
                    </li>
                  </ul>
                  <!-- /.post-meta -->
                </div>
                <!-- /.post-header -->
                <div class="post-content">
                  <p>{{ item.description }}</p>
                </div>
                <div class="post-content" v-html="item.htmlPart"></div>
                <!-- /.post-content -->
                <div class="boxactions d-flex" mt-5>
                  <button
                    v-if="!selected"
                    class="btn btn-outline-blue rounded-pill mb-2 me-1 tts"
                    @click="setProductForQuot"
                  >
                    Add for quotation
                  </button>
                  <button
                    v-else
                    class="btn btn-outline-orange rounded-pill mb-2 me-1 tts"
                    @click="RemoveProductForQuot"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </article>
            <!-- /.post -->
          </div>
          <!-- /column -->
          <div class="col-12">
            <div class="row gy-10">
              <div
                v-for="pro in item.album"
                :key="pro.id"
                class="col-md-6 col-lg-6"
              >
                <article class="post">
                  <figure class="overlay overlay1 hover-scale rounded mb-5">
                    <a href="#">
                      <img
                        :src="asset + pro.path"
                        :alt="item.title"
                        class="imgBoxing"
                      />
                    </a>
                  </figure>
                  <div class="post-header">
                    <div class="post-category text-line">
                      <a href="#" class="hover" rel="category">{{
                        item.category.name
                      }}</a>
                    </div>
                  </div>
                  <!-- /.post-footer -->
                </article>
                <!-- /.post -->
              </div>
            </div>
            <!-- /.row -->
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
        <!-- /section -->
        <section
          v-if="item.pps.length > 0"
          class="wrapper bg-light wrapper-border"
        >
          <div class="container py-14 py-md-16">
            <h2 class="display-5 mb-7 text-center">Nos tarifs</h2>
            <div class="pricing-wrapper">
              <div class="row gx-0 gy-6 mt-2">
                <div
                  class="col-md-6 col-lg-4"
                  v-for="p in item.pps"
                  :key="p.id"
                >
                  <div class="pricing m-2 bg-soft-purple card shadow-none">
                    <div class="card-body">
                      <div
                        class="
                          icon
                          btn btn-circle btn-lg btn-soft-purple
                          disabled
                        "
                      >
                        <i :class="p.icon"></i>
                      </div>
                      <h4 class="card-title">{{ p.name }}</h4>
                      <div class="prices text-dark">
                        <div class="price price-show">
                          <span class="price-currency">MAD</span>
                          <span class="price-value">{{ p.price }}</span>
                          <span class="price-duration">joindre</span>
                        </div>
                      </div>
                      <!--/.prices -->
                      <div class="htmlpart" v-html="p.htmlPart"></div>
                      <a href="#" class="btn btn-soft-purple rounded-pill"
                        >Choose Plan</a
                      >
                    </div>
                    <!--/.card-body -->
                  </div>
                  <!--/.pricing -->
                </div>
              </div>
              <!--/.row -->
            </div>
            <!--/.pricing-wrapper -->
          </div>
          <!-- /.container -->
        </section>
        <!-- /section -->
      </div>
      <!-- /.container -->
    </section>

    <singleProjectIntroVue
      :vtitle="item.category.name"
      vdescription="Products with the same category"
      :vcreated_at="new Date()"
    ></singleProjectIntroVue>
    <section class="wrapper bg-light">
      <div class="container py-14 py-md-16">
        <div class="grid grid-view projects-masonry">
          <div
            v-if="productByCat != null"
            class="row gx-md-8 gy-10 gy-md-13 isotope"
          >
            <CardProduct
              v-for="el in productByCat.data"
              :key="el.id"
              :item="item"
              :asset="asset"
            >
            </CardProduct>
          </div>
          <div class="form-select-wrapper">
            <select class="form-select" v-model="url">
              <option v-for="(lab, i) in productByCat.links" :key="i">
                <Link
                  :href="lab.url"
                  class="badge rounded-pill bg-blue mr-2"
                  v-if="i > 1 && i < productByCat.links.length - 1"
                  >{{ lab.label }}</Link
                >
              </option>
            </select>
          </div>

          <!-- /.row -->
        </div>
        <!-- /.grid -->
      </div>
      <!-- /.container -->
    </section>
  </div>
</template>
<script>
import { Link } from "@inertiajs/inertia-vue3";
import singleProjectIntroVue from "./Partials/singleProjectIntro.vue";
import allproductsVue from "./allproducts.vue";
import CardProduct from "./Partials/cardProduct.vue";

export default {
  components: {
    singleProjectIntroVue,
    Link,
    CardProduct,
    allproductsVue,
  },
  props: ["asset", "item", "productByCat"],
  methods: {
    setProductForQuot() {
      this.$store.commit("setproductsForQuot", this.item);
      this.selected = true;
    },
    RemoveProductForQuot() {
      this.$store.commit("RemoveProductForQuot", this.item);
      this.selected = false;
    },
    init() {
      var i = this.rfq.findIndex((e) => e.id == this.item.id);
      this.selected = i != -1 ? true : false;
    },
  },
  created() {
    this.init();
  },
  data() {
    return {
      url: null,
      selected: false,
    };
  },
  watch: {
    url: function () {
      this.$inertia.get(this.productByCat.path + "?page=" + this.url);
    },
  },
  computed: {
    rfq() {
      return this.$store.getters.getproductsForQuot;
    },
  },
};
</script>
<style scoped>
.boxactions.d-flex {
  gap: 15px;
  margin-top: 17px;
}
</style>
