<template>
  <div class="fancy-short-banner-nine mt-170 md-mt-80">
    <div class="container">
      <div class="row">
        <div
          class="col-xl-8 col-lg-11 m-auto"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          <div class="title-style-seven text-center">
            <h2>+100 Customer start there project with vanotic</h2>
            <p>Try our service and be one of our customer let's go</p>
          </div>
        </div>
      </div>

      <div class="d-flex counters row mt-10">
        <div class="col-12 col-md-4 mt-2">
          <div class="card shadow-lg p-3">
            <div class="icon btn btn-circle btn-lg btn-soft-purple">
              <i class="uil uil-presentation-check"></i>
            </div>
            <div class="content mt-3">
              <h3 class="counter mb-1">+120 Projects Done</h3>
              <p class="mb-0">Let's build your project</p>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 mt-2">
          <div class="card shadow-lg p-3">
            <div class="icon btn btn-circle btn-lg btn-soft-red">
              <i class="uil uil-users-alt"></i>
            </div>
            <div class="content mt-3">
              <h3 class="counter mb-1">+50 happy customers</h3>
              <p class="mb-0">be one of our happy customers</p>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 mt-2">
          <div class="card shadow-lg p-3">
            <div class="icon btn btn-circle btn-lg btn-soft-yellow">
              <i class="uil uil-user-check"></i>
            </div>
            <div class="content mt-3">
              <h3 class="counter mb-1">+61 expert</h3>
              <p class="mb-0">Be one of our experts</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container -->
  </div>
</template>
<style scoped>
.fancy-short-banner-nine {
  background: #4b0e55;
  padding: 110px 0;
  position: relative;
  z-index: 1;
}
.fancy-short-banner-nine .title-style-seven h2,
.fancy-short-banner-nine .title-style-seven p {
  color: #fff;
}
.fancy-short-banner-nine .download-btn {
  width: 250px;
  margin: 50px auto 0;
}
.fancy-short-banner-nine .download-btn button {
  width: 100%;
  line-height: 65px;
  border-radius: 40px;
  font-weight: 500;
  font-size: 18px;
  color: #000;
  background: #fff;
  text-align: center;
}
.fancy-short-banner-nine .download-btn button:after {
  border: none;
  position: absolute;
  right: 30px;
  vertical-align: 0;
  transition: all 0.2s ease-in-out;
}
.fancy-short-banner-nine .download-btn.show button:after {
  transform: rotate(180deg);
}
.fancy-short-banner-nine .download-btn .dropdown-menu {
  width: 100%;
  background: #fff;
  border-radius: 0px 0px 10px 10px;
  border: none;
  margin: -5px 0 0 0;
  padding: 5px 0 0px;
}
.fancy-short-banner-nine .download-btn .dropdown-menu a {
  font-weight: 500;
  font-size: 15px;
  color: #000;
  padding: 8px 15px;
  background: transparent;
}

.fancy-short-banner-nine .download-btn .dropdown-menu a span {
  padding-left: 12px;
}
.fancy-short-banner-nine .shape-one {
  bottom: 0;
  right: 0;
  width: 18%;
}
.fancy-short-banner-nine .shape-two {
  bottom: 0;
  left: 0;
  width: 17.4%;
}
</style>
