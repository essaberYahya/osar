<template>
  <div class="col-md-3 col-lg-3 m-0 p-0 col-6">
    <div class="item">
      <div class="item-inner">
        <article>
          <div class="card">
            <figure class="card-img-top overlay overlay1 hover-scale">
              <Link
                :href="
                  route('singleObjectSell', {
                    id: item.id,
                    title: item.title.replace(' ', '-'),
                  })
                "
              >
                <img class="imgelearn" :src="asset + item.pictureCover" alt=""
              /></Link>
              <figcaption>
                <h5 class="from-top mb-0">Voir plus</h5>
              </figcaption>
            </figure>
            <div class="card-body">
              <span
                v-if="!selected"
                @click="setProductForQuot"
                style="cursor: pointer"
                class="badge bg-blue rounded-pill mt-2 mb-4 ml-2"
                >Select</span
              >
              <span
                v-else
                @click="RemoveProductForQuot"
                style="cursor: pointer"
                class="badge bg-orange rounded-pill mt-2 mb-4 ml-2"
                >Remove</span
              >
              <div class="post-header">
                <div class="post-category text-line">
                  <a v-if="item.title" href="#" class="hover" rel="category">
                    {{ item.title }}
                  </a>
                </div>
                <!-- /.post-category -->
                <p>{{ item.description.substring(0, 50) }}</p>
              </div>
              <!-- /.post-header -->
            </div>
          </div>
          <!-- /.card -->
        </article>
        <!-- /article -->
      </div>
      <!-- /.item-inner -->
    </div>
  </div>
</template>
<script>
import { Link } from "@inertiajs/inertia-vue3";

export default {
  setup() {},
  props: ["item", "asset"],
  data() {
    return {
      selected: false,
    };
  },
  components: {
    Link,
  },
  created() {
    this.init();
  },
  methods: {
    setProductForQuot() {
      this.$store.commit("setproductsForQuot", this.item);
      this.selected = true;
    },
    RemoveProductForQuot() {
      this.$store.commit("RemoveProductForQuot", this.item);
      this.selected = false;
    },
    init() {
      var i = this.rfq.findIndex((e) => e.id == this.item.id);
      this.selected = i != -1 ? true : false;
    },
  },
  computed: {
    rfq() {
      return this.$store.getters.getproductsForQuot;
    },
  },
};
</script>
<style scoped>
img.imgelearn {
  height: 150px !important;
  object-fit: contain;
}

@media (max-width: 767px) {
  .post-category.text-line {
    font-size: 11px;
  }
  p {
    font-size: 10px;
  }
}
</style>
