<template>
  <div id="comments">
    <h3 class="mb-6">5 Comments</h3>
    <ol id="singlecomments" class="commentlist">
      <li class="comment">
        <div class="comment-header d-md-flex align-items-center">
          <div class="d-flex align-items-center">
            <figure class="user-avatar">
              <img class="rounded-circle" alt="" />
            </figure>
            <div>
              <h6 class="comment-author">
                <a href="#" class="link-dark">Connor Gibson</a>
              </h6>
              <ul class="post-meta">
                <li><i class="uil uil-calendar-alt"></i>14 Jan 2021</li>
              </ul>
              <!-- /.post-meta -->
            </div>
            <!-- /div -->
          </div>
          <!-- /div -->
          <div class="mt-3 mt-md-0 ms-auto">
            <a
              href="#"
              class="
                btn btn-soft-ash btn-sm
                rounded-pill
                btn-icon btn-icon-start
                mb-0
              "
              ><i class="uil uil-comments"></i> Reply</a
            >
          </div>
          <!-- /div -->
        </div>
        <!-- /.comment-header -->
        <p>
          Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis
          vestibulum. Duis mollis, est non commodo luctus, nisi erat porttitor
          ligula, eget lacinia odio sem nec elit. Sed posuere consectetur est at
          lobortis integer posuere erat ante.
        </p>
      </li>
    </ol>
  </div>
</template>
<script>
export default {};
</script>
