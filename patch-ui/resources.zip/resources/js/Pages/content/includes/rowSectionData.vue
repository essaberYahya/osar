<template>
    <section id="features" class="wrapper bg-light" style="padding:5%;">
      <div class="container pb-8 pb-lg-10">
        <div class="gx-lg-8  gx-xl-12 gy-10 mb-15 mb-md-18 align-items-center" v-for="rsd in rowSectionData" :key="rsd.id">

        <div v-if="rsd.leftToRight" class="row lefttorigth">
            <div class="col-lg-5 mb-5">
            <figure><img class="" :src="rsd.picture" :srcset="rsd.picture" alt="" /></figure>
          </div>
          <!--/column -->
          <div class="col-lg-7">
            <h3 class="display-4 mb-3">{{rsd.title}}</h3>
            <p class="mb-6">
                {{rsd.description}}
            </p>
            <div v-html="rsd.htmlPart" class="htmlPart">

            </div>
            <!--/.row -->
          </div>
          <!--/column -->
        </div>
        <div v-else class="row lefttorigth">

          <!--/column -->
          <div class="col-lg-7">
            <h3 class="display-4 mb-3">{{rsd.title}}</h3>
            <p class="mb-6">
                {{rsd.description}}
            </p>
            <div v-html="rsd.htmlPart" class="htmlPart">

            </div>
            <!--/.row -->
          </div>
          <div class="col-lg-5 mb-5">
            <figure><img class="" :src="rsd.picture" :srcset="rsd.picture" alt="" /></figure>
          </div>
          <!--/column -->
        </div>
        </div>
      </div>
      <!-- /.container -->
    </section>
</template>
<script>
export default {
    props : ["rowSectionData"]
}
</script>
