<template>
  <div class="container">
    <section
      class="
        wrapper
        bg-light
        position-relative
        min-vh-70
        d-lg-flex
        align-items-center
      "
    >
      <div
        class="
          rounded-4-lg-start
          col-lg-6
          order-lg-2
          position-lg-absolute
          top-0
          end-0
          image-wrapper
          bg-image bg-cover
          h-100
          min-vh-50
        "
        :data-image-src="asset + intro.backgroundimg"
      ></div>
      <!--/column -->
      <div class="container mt-5">
        <div class="row">
          <div class="col-lg-6">
            <div
              class="
                mt-10 mt-md-11
                px-md-11
                ps-lg-0
                pe-lg-13
                text-center text-lg-start
                bglock
              "
            >
              <h1 class="display-1 mb-5 ttf">{{ intro.title }}</h1>
              <p class="lead fs-25 lh-sm mb-7 pe-md-10 tts">
                {{ intro.description }}
              </p>
              <div v-html="intro.htmlPart" class="htmlpart"></div>
            </div>
            <!--/div -->
          </div>
          <!--/column -->
        </div>
        <!--/.row -->
      </div>
      <!-- /.container -->
    </section>
  </div>
</template>

<script>
import { Link } from "@inertiajs/inertia-vue3";
export default {
  props: ["intro", "asset"],
  components: {
    Link,
  },
};
</script>
<style scoped>
</style>
