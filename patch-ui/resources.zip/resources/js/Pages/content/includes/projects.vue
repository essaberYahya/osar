<template>
    <section id="nosprojets" class="wrapper bg-light wrapper-border">
        <div class="container py-14 py-md-16">
            <h2 class="display-4 mb-3 text-center">TAKE A LOOK ON WHAT WE BUILD</h2>
            <p
                class="lead fs-lg mb-10 text-center px-md-16 px-lg-21 px-xl-0"
            >Check out some of our awesome projects with creative ideas and great design</p>
            <div class="row">
                <div v-for="pro in oprojects" :key="pro.id" class="item col-md-4 col-6">
                    <article>
                        <figure class="overlay overlay1 hover-scale rounded mb-5">
                            <Link :href="route('project',{'id' : pro.id , 'title' : pro.title})">
                                <img class="projectpicture" :src="asset+pro.cover" alt />
                            </Link>
                            <figcaption>
                                <h5 class="from-top mb-0">Learn more</h5>
                            </figcaption>
                        </figure>
                        <div class="post-header">
                            <div class="post-category text-line">
                                <a href="#" class="hover" rel="category">{{ pro.category.name }}</a>
                            </div>
                            <!-- /.post-category -->
                            <h2 class="post-title h3 mt-1 mb-3">{{ pro.title }}</h2>
                        </div>
                        <!-- /.post-header -->
                        <div class="post-footer">
                            <ul class="post-meta">
                                <li class="post-date">
                                    <i class="uil uil-calendar-alt"></i>
                                    <span>{{ new Date(pro.created_at).toDateString() }}</span>
                                </li>
                                <li class="post-comments">
                                    <a href="#">
                                        <i class="uil uil-comment"></i>4
                                    </a>
                                </li>
                            </ul>
                            <!-- /.post-meta -->
                        </div>
                        <!-- /.post-footer -->
                    </article>
                    <!-- /article -->
                </div>
            </div>
        </div>

        <!-- /.container -->
    </section>
</template>
<script>
    /**
    *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
    *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */

import { Link } from '@inertiajs/inertia-vue3';
export default {
    props : ["oprojects","asset"],
    components : {
        Link
    },
}
</script>
