<template>
  <div>
    <section id="latesttraining" class="wrapper bglock bg-light wrapper-border">
      <div class="container py-14 py-md-16">
        <div class="row">
          <div class="col-lg-9 col-xl-8 col-xxl-7 mx-auto">
            <h2 class="fs-15 text-uppercase text-primary text-center">
              OUR IT products
            </h2>
            <h3 class="display-4 mb-6 text-center">
              Here is the latest news of our computer products that have
              retained the more attention from our customers.
            </h3>
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
        <div class="container mt-4">
          <div class="row">
            <cardProductVue
              v-for="item in elearnings"
              :key="item.id"
              :item="item"
              :asset="asset"
            >
            </cardProductVue>
            <div class="cotainer text-center mt-5">
              <Link href="/products" class="btn btn-soft-info rounded-pill mb-0"
                >See all products</Link
              >
            </div>
          </div>
        </div>

        <!-- /.position-relative -->
      </div>

      <!-- /.container -->
    </section>
  </div>
</template>
<script>
import { Link } from "@inertiajs/inertia-vue3";
import cardProductVue from "./Partials/cardProduct.vue";

export default {
  props: ["elearnings", "asset"],
  components: {
    Link,
    cardProductVue,
  },
  methods: {
    setProductForQuot($item) {
      this.$store.commit("setproductsForQuot", $item);
    },
  },
};
</script>

<style scoped>
img.imgelearn {
  height: 150px !important;
  object-fit: contain;
}
</style>
