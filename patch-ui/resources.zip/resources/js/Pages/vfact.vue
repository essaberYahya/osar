<template>
    <factVue></factVue>
</template>
<script>
import factVue from "./content/includes/fact.vue"


export default {
        components : {
            factVue
        }
}
</script>
