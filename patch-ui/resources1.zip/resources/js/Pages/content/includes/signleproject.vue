<template>
    <div>
        <singleProjectIntroVue :vtitle="project.category.name" :vdescription="project.title" :vcreated_at="project.created_at"></singleProjectIntroVue>
        <!-- /header -->
        <!-- /section -->
         <section class="wrapper bg-light wrapper-border">
            <div class="container py-14 py-md-16">
                <div class="row align-items-center mb-10">
                    <div class="col-md-8 col-lg-9 col-xl-8 col-xxl-7 pe-xl-20">
                        <h3
                            class="display-4 mb-0 tts"
                        >Check out some of our awesome projects with creative ideas and great design.</h3>
                    </div>
                    <!--/column -->
                    <div class="col-md-4 col-lg-3 ms-md-auto text-md-end mt-5 mt-md-0">
                        <Link href="/all-projects" class="btn btn-soft-orange rounded-pill mb-0">See all projects</Link>
                    </div>
                    <!--/column -->
                </div>
                <!--/.row -->
                <div class="row gx-lg-8 gx-xl-11 gy-10 blog grid-view">
                    <div class="col-lg-8">
                        <article class="post">
                            <div class="rounded mb-6">
                                <img :src="asset + project.cover" class alt />
                                <!-- /.basic-slider -->
                            </div>
                            <!-- /.post-slider -->
                            <div class="post-header mb-5">
                                <div class="post-category text-line">
                                    <a
                                        href="#"
                                        class="hover"
                                        rel="category"
                                    >{{ project.category.name }}</a>
                                </div>
                                <!-- /.post-category -->
                                <h2 class="post-title mt-1 mb-4">{{ project.title }}</h2>
                                <ul class="post-meta mb-0">
                                    <li class="post-date">
                                        <i class="uil uil-calendar-alt"></i>
                                        <span>Created at : {{ new Date(project.created_at).toDateString() }}</span>
                                    </li>

                                </ul>
                                <!-- /.post-meta -->
                            </div>
                            <!-- /.post-header -->
                            <div class="post-content">
                                <p>{{ project.description }}</p>
                            </div>
                            <div class="post-content" v-html="project.htmlPart"></div>
                            <!-- /.post-content -->
                        </article>
                        <!-- /.post -->
                    </div>
                    <!-- /column -->
                    <div class="col-lg-4">
                        <div class="row gy-10">
                            <div v-for="pro in project.album" :key="pro.id" class="col-md-6 col-lg-12">
                                <article class="post">
                                    <figure class="overlay overlay1 hover-scale rounded mb-5">
                                        <a href="#">
                                            <img :src="asset + pro.picture" alt />
                                        </a>
                                    </figure>
                                    <div class="post-header">
                                        <div class="post-category text-line">
                                            <a
                                                href="#"
                                                class="hover"
                                                rel="category"
                                            >{{ project.category.name }}</a>
                                        </div>
                                    </div>
                                    <!-- /.post-footer -->
                                </article>
                                <!-- /.post -->
                            </div>
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /column -->
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </section>
        <!-- /section -->
    </div>
</template>
<script>
import { Link } from '@inertiajs/inertia-vue3'
import commentsVue from './Partials/comments.vue'
import singleProjectIntroVue from './Partials/singleProjectIntro.vue'



export default {
    props: ["project", "asset", "myinteresting"],
    components: {
        singleProjectIntroVue,
        commentsVue,
        Link
    },
    created() {
        var d = document, s = d.createElement('script');
        s.src = 'https://pkconculting.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    }
}
</script>

<style scoped>
.hero-slider-wrapper .hero-slider .owl-slide.bg-overlay-400:before {
    background: transparent !important;
}
</style>
