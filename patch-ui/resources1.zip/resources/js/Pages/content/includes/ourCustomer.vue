<template>
  <div
    class="fancy-short-banner-nine mt-170 md-mt-80"
    style="background-image: url(../../../../img/photos/bg2.jpg)"
  >
    <div class="container">
      <div class="row">
        <div
          class="col-xl-8 col-lg-11 m-auto"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          <div class="title-style-seven text-center">
            <h1 class="text-white">OUR CLIENTS & PARTNERS</h1>
            <h2>
              We are trusted by over 100+ clients and partners. Join them by
              using our services and grow your business.
            </h2>
            <p>Try our service and be one of our customer let's go</p>
          </div>
        </div>
      </div>

      <div
        class="
          row row-cols-2 row-cols-md-3 row-cols-xl-5
          gx-lg-6
          gy-6
          justify-content-center
        "
      >
        <div v-for="oc in ourCustomer" :key="oc.id" class="col">
          <div class="card shadow-lg h-100 align-items-center">
            <div class="card-body align-items-center d-flex px-3 py-6 p-md-8">
              <figure class="px-md-3 mb-0">
                <img :src="oc.picture" :alt="oc.name" />
              </figure>
            </div>
            <!--/.card-body -->
          </div>
          <!--/.card -->
        </div>
      </div>
    </div>
    <!-- /.container -->
  </div>
</template>
<script>
export default {
  props: ["ourCustomer"],
};
</script>
<style scoped>
.fancy-short-banner-nine {
  background: #4b0e55;
  padding: 110px 0;
  position: relative;
  z-index: 1;
}
.fancy-short-banner-nine .title-style-seven h2,
.fancy-short-banner-nine .title-style-seven p {
  color: #fff;
}
.fancy-short-banner-nine .download-btn {
  width: 250px;
  margin: 50px auto 0;
}
.fancy-short-banner-nine .download-btn button {
  width: 100%;
  line-height: 65px;
  border-radius: 40px;
  font-weight: 500;
  font-size: 18px;
  color: #000;
  background: #fff;
  text-align: center;
}
.fancy-short-banner-nine .download-btn button:after {
  border: none;
  position: absolute;
  right: 30px;
  vertical-align: 0;
  transition: all 0.2s ease-in-out;
}
.fancy-short-banner-nine .download-btn.show button:after {
  transform: rotate(180deg);
}
.fancy-short-banner-nine .download-btn .dropdown-menu {
  width: 100%;
  background: #fff;
  border-radius: 0px 0px 10px 10px;
  border: none;
  margin: -5px 0 0 0;
  padding: 5px 0 0px;
}
.fancy-short-banner-nine .download-btn .dropdown-menu a {
  font-weight: 500;
  font-size: 15px;
  color: #000;
  padding: 8px 15px;
  background: transparent;
}

.fancy-short-banner-nine .download-btn .dropdown-menu a span {
  padding-left: 12px;
}
.fancy-short-banner-nine .shape-one {
  bottom: 0;
  right: 0;
  width: 18%;
}
.fancy-short-banner-nine .shape-two {
  bottom: 0;
  left: 0;
  width: 17.4%;
}
</style>
