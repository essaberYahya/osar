<template>
    <div>
        <section class="wrapper image-wrapper bg-image bg-overlay text-white" data-image-src="../../../../../img/photos/bg3.jpg">
      <div class="container pt-17 pb-13 pt-md-19 pb-md-17 text-center">
        <div class="row">
          <div class="col-md-10 col-xl-8 mx-auto">
            <div class="post-header">
              <div class="post-category text-line text-white">
                <a href="#" class="text-reset" rel="category">{{vtitle}}</a>
              </div>
              <!-- /.post-category -->
              <h1 class="display-1 mb-4 text-white">{{vdescription}}</h1>
              <ul class="post-meta text-white">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>{{new Date(vcreated_at).toDateString()}}</span></li>
              </ul>
              <!-- /.post-meta -->
            </div>
            <!-- /.post-header -->
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
    </div>
</template>
<script>
export default {
    props : ["vtitle","vdescription","vcreated_at"]
}
</script>
