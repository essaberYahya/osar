<template>
  <div class="footercontainer">
    <footer class="bg-white">
      <div class="container pt-13 pt-md-15 pb-7">
        <div
          class="
            card
            image-wrapper
            bg-full bg-image bg-overlay bg-overlay-400
            mb-13
          "
          data-image-src="../../../../img/photos/bg2.jpg"
        >
          <div class="card-body p-9 p-xl-11">
            <div class="row align-items-center gy-6">
              <div class="col-lg-7">
                <h3 class="display-5 text-white">
                  Subscribe to our newsletter
                </h3>
                <p class="lead pe-lg-12 mb-0 text-white">
                  Subscribe to our newsletter to get our news & deals delivered
                  to you. Don't worry, we hate spam and we respect your privacy.
                </p>
                <div class="newsletter-wrapper mt-4">
                  <!-- Begin Mailchimp Signup Form -->
                  <div id="mc_embed_signup2">
                    <form>
                      <div id="mc_embed_signup_scroll2">
                        <div class="mc-field-group input-group">
                          <input
                            type="email"
                            value=""
                            name="EMAIL"
                            class="required email form-control"
                            placeholder="Email Address"
                            id="mce-EMAIL2"
                          />
                          <input
                            type="submit"
                            value="rejoindre"
                            name="subscribe"
                            id="mc-embedded-subscribe2"
                            class="btn btn-primary"
                          />
                        </div>
                        <div id="mce-responses2" class="clear">
                          <div
                            class="response"
                            id="mce-error-response2"
                            style="display: none"
                          ></div>
                          <div
                            class="response"
                            id="mce-success-response2"
                            style="display: none"
                          ></div>
                        </div>
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                        <div
                          style="position: absolute; left: -5000px"
                          aria-hidden="true"
                        >
                          <input
                            type="text"
                            name="b_ddc180777a163e0f9f66ee014_4b1bcfa0bc"
                            tabindex="-1"
                            value=""
                          />
                        </div>
                        <div class="clear"></div>
                      </div>
                    </form>
                  </div>
                  <!--End mc_embed_signup-->
                </div>
              </div>
              <!-- /column -->
              <div class="col-lg-5 col-xl-4 offset-xl-1">
                <div class="newsletter-wrapper"></div>
                <!-- /.newsletter-wrapper -->
              </div>
              <!-- /column -->
            </div>
            <!-- /.row -->
          </div>
          <!--/.card-body -->
        </div>
        <!--/.card -->
        <div class="row">
          <div class="container text-center">
            <JetApplicationMark class="mb-2"></JetApplicationMark>
          </div>
        </div>
        <div class="row">
          <div class="col-12 col-md-6 mt-3">
            <div class="widget">
              <h3 class="h2 mb-3">Join the Community</h3>
              <p class="lead mb-5">{{ settings.content }}</p>
              <a href="#" class="btn btn-primary rounded-pill">Join us</a>
            </div>
            <!-- /.widget -->
          </div>
          <!-- /column -->
          <div class="col-12 col-md-2 mt-3">
            <div class="widget">
              <h4 class="widget-title mb-3">Social media</h4>
              <ul class="list-unstyled text-reset mb-0">
                <li>
                  <a :href="settings.facebook">
                    <i class="uil uil-facebook-f"></i> Facebook</a
                  >
                </li>
                <li>
                  <a :href="settings.twitter">
                    <i class="uil uil-twitter"></i> Twitter</a
                  >
                </li>
                <li>
                  <a :href="settings.instagram">
                    <i class="uil uil-instagram"></i> Instagram</a
                  >
                </li>
                <li>
                  <a :href="'mailto:' + settings.email">
                    <i class="uil uil-envelope-check"></i> Email</a
                  >
                </li>
              </ul>
            </div>
            <!-- /.widget -->
          </div>

          <div class="col-12 col-md-4 mt-3">
            <div class="widget">
              <h4 class="widget-title mb-3">Contact</h4>
              <ul class="list-unstyled text-reset mb-0">
                <li>
                  <i class="uil uil-envelope-check"></i> Email :
                  {{ settings.email }}
                </li>
                <li>
                  <i class="uil uil-phone"></i> phone 1 : {{ settings.phone }}
                </li>
                <li>
                  <i class="uil uil-phone-volume"></i> phone 2 :
                  {{ settings.fix }}
                </li>
                <li>
                  <i class="uil uil-envelope-minus"></i> Whatsapp :
                  {{ settings.whatsapp }}
                </li>
              </ul>
            </div>
            <!-- /.widget -->
          </div>
        </div>
        <!--/.row -->
        <hr class="mt-13 mt-md-15 mb-7" />
        <div class="d-md-flex align-items-center justify-content-between">
          <p class="mb-2 mb-lg-0">© 2021 vanotic. All rights reserved.</p>
          <nav class="nav social text-md-end">
            <a :href="settings.twitter"><i class="uil uil-twitter"></i></a>
            <a :href="settings.facebook"><i class="uil uil-facebook-f"></i></a>
            <a :href="settings.instagram"><i class="uil uil-instagram"></i></a>
          </nav>
          <!-- /.social -->
        </div>
        <!-- /div -->
      </div>
      <!-- /.container -->
    </footer>
    <div class="progress-wrap">
      <svg
        class="progress-circle svg-content"
        width="100%"
        height="100%"
        viewBox="-1 -1 102 102"
      >
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
      </svg>
    </div>
  </div>
</template>
<script>
import JetApplicationMark from "@/Jetstream/ApplicationMark.vue";
export default {
  props: ["settings"],
  components: {
    JetApplicationMark,
  },
};
</script>
