<template>
  <div class="notybar bg-primary text-white fw-bold fs-15 mb-2">
    <div class="container py-2 d-md-flex flex-md-row">
      <div class="d-flex flex-row align-items-center">
        <div class="icon text-white fs-22 mt-1 me-2">
          <i class="uil uil-location-pin-alt"></i>
        </div>
        <address class="mb-0">{{ settings.adress }}</address>
      </div>
      <div class="d-flex flex-row align-items-center me-6 ms-auto">
        <div class="icon text-white fs-22 mt-1 me-2">
          <i class="uil uil-phone-volume"></i>
        </div>
        <p class="mb-0">{{ settings.phone }}</p>
      </div>
      <div class="d-flex flex-row align-items-center">
        <div class="icon text-white fs-22 mt-1 me-2">
          <i class="uil uil-message"></i>
        </div>
        <p class="mb-0">
          <a
            :href="'mailto:' + settings.email"
            target="_blank"
            class="link-white hover"
            >{{ settings.email }}</a
          >
        </p>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-expand-lg navbar-light caret-none navbar-bg-light">
    <div class="container">
      <div
        class="
          navbar-collapse-wrapper
          bg-white
          d-flex
          flex-row flex-nowrap
          w-100
          justify-content-between
          align-items-center
        "
      >
        <div class="navbar-brand w-100">
          <Link :href="route('welcome')">
            <jet-application-mark class="block h-10 w-auto" />
          </Link>
        </div>
        <div :class="navState">
          <div class="offcanvas-header d-lg-none d-xl-none">
            <Link :href="route('welcome')">
              <jet-application-mark class="block h-10 w-auto" />
            </Link>
            <button
              type="button"
              class="
                btn-close btn-close-white
                offcanvas-close offcanvas-nav-close
              "
              aria-label="Close"
              @click="sswitch"
            ></button>
          </div>

          <ul class="navbar-nav">
            <li class="nav-item" v-for="nav in navitems" :key="nav.id">
              <Link class="nav-link" :href="nav.routeLink">{{ nav.name }}</Link>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link"
                id="nser"
                @mouseover="this.dropstyle = 'display:block;'"
                >Hardware products</a
              >
              <ul
                class="dropdown-menu"
                @mouseleave="this.dropstyle = 'display:none;'"
                :style="dropstyle"
              >
                <li class="nav-item" v-for="c in categories" :key="c.id">
                  <Link
                    class="dropdown-item"
                    :href="'/products/category/' + c.id + '/' + c.name"
                    >{{ c.name }}</Link
                  >
                </li>
              </ul>
            </li>
          </ul>
          <!-- /.navbar-nav -->
        </div>
        <!-- /.navbar-collapse -->
        <div class="navbar-other w-100 d-flex ms-auto">
          <ul
            class="navbar-nav flex-row align-items-center ms-auto"
            data-sm-skip="true"
          >
            <li class="nav-item social">
              <nav
                class="
                  nav
                  social social-muted
                  ms-auto
                  justify-content-end
                  text-end
                "
              >
                <a :href="settings.twitter" target="_blank">
                  <i class="uil uil-twitter"></i>
                </a>
                <a :href="settings.facebook" target="_blank">
                  <i class="uil uil-facebook-f"></i>
                </a>
                <a :href="settings.instagram" target="_blank">
                  <i class="uil uil-instagram"></i>
                </a>
              </nav>
              <!-- /.social -->
            </li>

            <li class="nav-item d-lg-none">
              <div class="navbar-hamburger">
                <button
                  @click="sswitch"
                  class="hamburger animate plain"
                  data-toggle="offcanvas-nav"
                >
                  <span></span>
                </button>
              </div>
            </li>
          </ul>
          <!-- /.navbar-nav -->
        </div>
        <!-- /.navbar-other -->
      </div>
      <!-- /.navbar-collapse-wrapper -->
    </div>
    <!-- /.container -->
  </nav>
  <div class="quto" v-if="quot.length > 0">
    <Link href="/request-for-quotation">
      <div class="btnquto">Ask for quotation x{{ quot.length }}</div></Link
    >
  </div>
</template>
<script>
import { Head, Link } from "@inertiajs/inertia-vue3";
import JetApplicationMark from "@/Jetstream/ApplicationMark.vue";
export default {
  props: ["navitems", "settings", "categories"],
  components: {
    JetApplicationMark,
    Link,
  },
  data() {
    return {
      navState: "navbar-collapse offcanvas-nav d-lg-flex mx-lg-auto",
      navOpen: false,
      dropState: false,
      dropstyle: "display:none;",
    };
  },
  methods: {
    sswitch() {
      if (this.navOpen) {
        this.navOpen = false;
        this.navState = "navbar-collapse offcanvas-nav d-lg-flex mx-lg-auto";
      } else {
        this.navOpen = true;
        this.navState =
          "navbar-collapse offcanvas-nav d-lg-flex mx-lg-auto open";
      }
    },
  },
  computed: {
    quot() {
      return this.$store.getters.getproductsForQuot;
    },
  },
};
</script>
<style>
.dropdown-menu {
  min-width: 16rem !important;
}
.quto {
  position: fixed;
  top: 0px;
  left: 0px;
  width: 0px;
  height: 0px;
  background: rgba(0, 0, 0, 0);
  text-align: center;
  z-index: 99999;
}
.btnquto {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 200px;
  height: 64px;
  background: rgb(95, 127, 255);
  color: white;
  border-radius: 25px;
  position: fixed;
  right: 24px;
  bottom: 18px;
  box-shadow: rgb(0 0 0 / 40%) 0px 4px 8px;
  z-index: 9999;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease 0s;
  animation: jumpTwo 5s infinite linear;
}
</style>
